package com.example.previsao;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PrevisaoAdapter extends RecyclerView.Adapter<PrevisaoAdapter.PrevisaoViewHolder> {

    private List<Previsao> previsoes;

    public PrevisaoAdapter(List<Previsao> previsoes) {
        this.previsoes = previsoes;
    }

    @NonNull
    @Override
    public PrevisaoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_previsao, parent, false);
        return new PrevisaoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PrevisaoViewHolder holder, int position) {
        Previsao previsao = previsoes.get(position);
        holder.dataTextView.setText(previsao.getData());
        holder.temperaturaTextView.setText(previsao.getTemperatura());
    }

    @Override
    public int getItemCount() {
        return previsoes.size();
    }

    static class PrevisaoViewHolder extends RecyclerView.ViewHolder {
        TextView dataTextView;
        TextView temperaturaTextView;

        public PrevisaoViewHolder(@NonNull View itemView) {
            super(itemView);
            dataTextView = itemView.findViewById(R.id.dataTextView);
            temperaturaTextView = itemView.findViewById(R.id.temperaturaTextView);
        }
    }
}

public class PrevisaoAdapter extends RecyclerView.Adapter<PrevisaoAdapter.PrevisaoViewHolder> {

    private List<Previsao> previsoes;

    public PrevisaoAdapter(List<Previsao> previsoes) {
        this.previsoes = previsoes;
    }

    @Override
    public PrevisaoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_previsao, parent, false);
        return new PrevisaoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PrevisaoViewHolder holder, int position) {
        Previsao previsao = previsoes.get(position);
        holder.dateTextView.setText(previsao.getDate());
        holder.tempTextView.setText(previsao.getTemp());
        holder.descriptionTextView.setText(previsao.getDescription());
    }

    @Override
    public int getItemCount() {
        return previsoes.size();
    }

    public static class PrevisaoViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView;
        TextView tempTextView;
        TextView descriptionTextView;

        public PrevisaoViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            tempTextView = itemView.findViewById(R.id.tempTextView);
            descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
        }
    }
}
