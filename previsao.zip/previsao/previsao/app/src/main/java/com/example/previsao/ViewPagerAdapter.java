package com.example.previsao;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {

    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new ListaPrevisaoFragment(); // Fragment para a lista de previsões
            case 1:
                return new SobreFragment(); // Fragment para a tela sobre
            default:
                return new ListaPrevisaoFragment();
        }
    }

    @Override
    public int getCount() {
        return 2; // Número de abas
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "Previsões"; // Nome da primeira aba
            case 1:
                return "Sobre"; // Nome da segunda aba
            default:
                return null;
        }
    }
}
