package com.example.previsao.api;

import retrofit2.Call;
import retrofit2.http.GET;

public interface WeatherService {

    @GET("weather?key=YOUR_API_KEY&city_name=São Paulo") // Substitua "YOUR_API_KEY" pela chave da API
    Call<WeatherResponse> getWeather();
}
